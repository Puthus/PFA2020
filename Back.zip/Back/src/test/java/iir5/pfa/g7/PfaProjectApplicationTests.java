package iir5.pfa.g7;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PfaProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
