package iir5.pfa.g7;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PfaProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(PfaProjectApplication.class, args);
	}

}
