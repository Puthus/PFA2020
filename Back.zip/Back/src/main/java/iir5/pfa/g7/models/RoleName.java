package iir5.pfa.g7.models;

public enum  RoleName {
    ROLE_GESTIONNAIRE,
    ROLE_RECENSEUR,
    ROLE_ADMIN
}